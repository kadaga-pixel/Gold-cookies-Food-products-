/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ScanStats, Language } from '../types';
import { translations } from '../translations';
import { FileText, Database, Layers, CheckCircle2, HardDrive, RefreshCw } from 'lucide-react';

interface ScannerStatsProps {
  stats: ScanStats;
  language: Language;
}

export const formatBytes = (bytes: number, decimals = 2): string => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

export const ScannerStats: React.FC<ScannerStatsProps> = ({ stats, language }) => {
  const t = translations[language];

  // Calculate percentage of reclaimable size
  const reclaimablePercent = stats.totalSize > 0 
    ? Math.min(100, Math.round((stats.duplicateSize / stats.totalSize) * 100)) 
    : 0;

  return (
    <div className="w-full flex flex-col gap-4" id="scanner-stats-container">
      {/* Real-time Progress Card */}
      {stats.isScanning && (
        <div className="bg-slate-950 text-white p-5 rounded-2xl border border-slate-800 shadow-xl" id="progress-bar-card">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono text-emerald-400 flex items-center gap-2">
              <RefreshCw className="h-3.5 w-3.5 animate-spin text-emerald-400" />
              {t.statsScanning}
            </span>
            <span className="text-sm font-bold font-mono text-white">
              {stats.currentProgress}%
            </span>
          </div>

          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-3">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-150 ease-out"
              style={{ width: `${stats.currentProgress}%` }}
            ></div>
          </div>

          <div className="flex flex-col gap-1">
            <p className="text-[11px] font-mono text-slate-400 truncate">
              {t.scannedStatus
                .replace('{count}', stats.totalFiles.toString())
                .replace('{total}', stats.totalFiles.toString())}
            </p>
            <p className="text-xs text-slate-300 truncate font-mono">
              📂 {stats.currentFileName || 'Reading folder contents...'}
            </p>
          </div>
        </div>
      )}

      {/* Grid of 4 beautiful metric blocks */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4" id="stats-grid">
        {/* Metric 1: Total Files */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-5 shadow-lg hover:border-slate-700 transition-all flex items-start space-x-3.5">
          <div className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl">
            <FileText className="h-5 w-5" />
          </div>
          <div>
            <span className="text-xs font-semibold text-slate-400 block">
              {t.statsTotalFiles}
            </span>
            <span className="text-lg md:text-2xl font-black text-white font-mono tracking-tight mt-0.5 block">
              {stats.totalFiles.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Metric 2: Total Size */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-5 shadow-lg hover:border-slate-700 transition-all flex items-start space-x-3.5">
          <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl">
            <Database className="h-5 w-5" />
          </div>
          <div>
            <span className="text-xs font-semibold text-slate-400 block">
              {t.statsTotalSize}
            </span>
            <span className="text-lg md:text-2xl font-black text-white font-mono tracking-tight mt-0.5 block">
              {formatBytes(stats.totalSize)}
            </span>
          </div>
        </div>

        {/* Metric 3: Duplicates Count */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-5 shadow-lg hover:border-slate-700 transition-all flex items-start space-x-3.5">
          <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
            <Layers className="h-5 w-5" />
          </div>
          <div>
            <span className="text-xs font-semibold text-slate-400 block">
              {t.statsDuplicates}
            </span>
            <span className="text-lg md:text-2xl font-black text-white font-mono tracking-tight mt-0.5 block">
              {stats.duplicateCount}
            </span>
          </div>
        </div>

        {/* Metric 4: Reclaimable Space */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-5 shadow-lg hover:border-slate-700 transition-all flex items-start space-x-3.5">
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <HardDrive className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-xs font-semibold text-slate-400 block">
              {t.statsSpaceReclaimable}
            </span>
            <span className="text-lg md:text-2xl font-black text-emerald-400 font-mono tracking-tight mt-0.5 block truncate">
              {formatBytes(stats.duplicateSize)}
            </span>
            {stats.duplicateSize > 0 && (
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-md mt-1 inline-block border border-emerald-900/40">
                -{reclaimablePercent}% Space Saved
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
