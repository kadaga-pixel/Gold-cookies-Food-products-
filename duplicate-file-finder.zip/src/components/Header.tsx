/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { FolderSync, Globe, Terminal } from 'lucide-react';

interface HeaderProps {
  language: Language;
  setLanguage: (lang: Language) => void;
}

export const Header: React.FC<HeaderProps> = ({ language, setLanguage }) => {
  const t = translations[language];

  return (
    <header className="w-full bg-slate-900 border-b border-slate-800 shadow-md" id="app-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-indigo-600 text-white h-11 w-11 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 font-sans font-black text-xl select-none" id="app-logo">
            F
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              {t.appTitle}
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                Local Engine
              </span>
            </h1>
            <p className="text-xs text-slate-400 font-mono hidden sm:block">
              {t.learnMoreScript}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="bg-slate-950 border border-slate-800 p-1 rounded-xl flex items-center space-x-1">
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                language === 'en'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              id="btn-lang-en"
            >
              EN
            </button>
            <button
              onClick={() => setLanguage('sw')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                language === 'sw'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              id="btn-lang-sw"
            >
              SW
            </button>
          </div>

          <a
            href="#python-instructions"
            className="flex items-center space-x-1 px-3.5 py-2 border border-slate-800 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition-all cursor-pointer bg-slate-900"
          >
            <Terminal className="h-4 w-4 text-indigo-400" />
            <span className="hidden md:inline">Python Logic</span>
          </a>
        </div>
      </div>

      <div className="bg-slate-950 text-slate-300 py-3.5 px-4 sm:px-6 lg:px-8 text-center text-xs md:text-sm border-t border-slate-800/50">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-left font-sans text-slate-400 text-xs sm:text-sm leading-relaxed">
            {t.appSubtitle}
          </p>
          <div className="flex items-center space-x-2 text-emerald-400 font-mono text-[11px] bg-slate-900 px-2.5 py-1 rounded-md border border-slate-850 shrink-0">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span>os.walk & md5 hasher ready</span>
          </div>
        </div>
      </div>
    </header>
  );
};
