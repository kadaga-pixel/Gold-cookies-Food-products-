/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { FolderOpen, ShieldCheck, Upload, FileUp, AlertCircle } from 'lucide-react';

interface FolderUploadProps {
  language: Language;
  onFilesSelected: (files: File[]) => void;
  isScanning: boolean;
}

export const FolderUpload: React.FC<FolderUploadProps> = ({
  language,
  onFilesSelected,
  isScanning,
}) => {
  const t = translations[language];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  // Parse dropped items recursively
  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (isScanning) return;

    const items = e.dataTransfer.items;
    if (!items) return;

    const files: File[] = [];
    const promises: Promise<File[]>[] = [];

    // Helper to traverse entries
    const traverseEntry = (entry: any, path = ''): Promise<File[]> => {
      return new Promise((resolve) => {
        if (entry.isFile) {
          entry.file((file: File) => {
            // Re-define relative path property to preserve structure
            const relPath = path ? `${path}/${file.name}` : file.name;
            Object.defineProperty(file, 'webkitRelativePath', {
              value: relPath,
              writable: true,
              configurable: true,
            });
            resolve([file]);
          });
        } else if (entry.isDirectory) {
          const reader = entry.createReader();
          const dirFiles: File[] = [];

          const readAll = () => {
            reader.readEntries(async (entries: any[]) => {
              if (entries.length === 0) {
                resolve(dirFiles);
              } else {
                const subPromises = entries.map((subEntry) =>
                  traverseEntry(subEntry, path ? `${path}/${entry.name}` : entry.name)
                );
                const subFilesLists = await Promise.all(subPromises);
                for (const subFiles of subFilesLists) {
                  dirFiles.push(...subFiles);
                }
                readAll(); // Recursive call to handle chrome chunk limitations
              }
            });
          };
          readAll();
        } else {
          resolve([]);
        }
      });
    };

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.kind === 'file') {
        const entry = item.webkitGetAsEntry();
        if (entry) {
          promises.push(traverseEntry(entry));
        } else {
          const file = item.getAsFile();
          if (file) files.push(file);
        }
      }
    }

    const resolved = await Promise.all(promises);
    const allFiles = [...files, ...resolved.flat()];
    
    if (allFiles.length > 0) {
      onFilesSelected(allFiles);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!isScanning) {
      setIsDragOver(true);
    }
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const onFolderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFilesSelected(Array.from(e.target.files));
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFilesSelected(Array.from(e.target.files));
    }
  };

  // Custom prop sets for directory & multi input
  const folderInputProps = {
    type: 'file',
    ref: folderInputRef,
    webkitdirectory: '',
    directory: '',
    multiple: true,
    className: 'hidden',
    onChange: onFolderChange,
  } as any;

  return (
    <div className="w-full" id="folder-upload-container">
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`border-2 border-dashed rounded-2xl p-8 md:p-12 text-center transition-all flex flex-col items-center justify-center cursor-pointer ${
          isScanning
            ? 'border-slate-800 bg-slate-900/50 cursor-not-allowed opacity-70'
            : isDragOver
            ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01] shadow-lg shadow-indigo-500/5'
            : 'border-slate-800 bg-slate-900 hover:border-slate-700 hover:bg-slate-900/80 shadow-md'
        }`}
        onClick={() => {
          if (!isScanning) {
            folderInputRef.current?.click();
          }
        }}
        id="drop-zone"
      >
        {/* Hidden File Inputs */}
        <input {...folderInputProps} />
        <input
          type="file"
          ref={fileInputRef}
          multiple
          className="hidden"
          onChange={onFileChange}
          id="raw-file-input"
        />

        <div className="p-4 bg-slate-950 rounded-full text-indigo-400 mb-4 border border-slate-850 shadow-md">
          <FolderOpen className="h-10 w-10 animate-pulse text-indigo-400" />
        </div>

        <h3 className="text-lg font-bold text-white mb-1">
          {t.dragDropTitle}
        </h3>
        <p className="text-xs text-slate-400 max-w-md mb-6 leading-relaxed">
          {language === 'en'
            ? 'Select any local folder (or individual files) on your drive. Subfolders will be recursively parsed and analyzed.'
            : 'Chagua folda yoyote ya kompyuta yako. Mafile yote yaliyo ndani na vijifolda vyake yatahesabiwa kwa usalama.'}
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
          <button
            type="button"
            disabled={isScanning}
            onClick={(e) => {
              e.stopPropagation();
              folderInputRef.current?.click();
            }}
            className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-semibold hover:bg-indigo-500 transition-all flex items-center justify-center space-x-2 shadow-lg shadow-indigo-600/20 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            id="btn-select-folder"
          >
            <FolderOpen className="h-4 w-4" />
            <span>{t.selectFolderBtn}</span>
          </button>

          <span className="text-xs font-semibold text-slate-500 py-1 font-mono">
            {t.dragDropOr}
          </span>

          <button
            type="button"
            disabled={isScanning}
            onClick={(e) => {
              e.stopPropagation();
              fileInputRef.current?.click();
            }}
            className="w-full sm:w-auto px-5 py-2.5 bg-slate-950 text-slate-300 border border-slate-800 rounded-xl text-xs font-semibold hover:bg-slate-850 hover:text-white transition-all flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            id="btn-select-files"
          >
            <FileUp className="h-4 w-4 text-indigo-400" />
            <span>{t.selectFilesBtn}</span>
          </button>
        </div>
      </div>

      {/* Trust & Privacy Card */}
      <div className="mt-4 bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-3.5 flex items-start space-x-3 text-[11px] md:text-xs text-emerald-400/90" id="privacy-card">
        <ShieldCheck className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-emerald-300 block mb-0.5">
            {language === 'en' ? 'Local-Only Architecture' : 'Ulinzi Imara wa Ndani (Kienyeji)'}
          </span>
          <p className="text-emerald-400/80 leading-relaxed">
            {t.localPrivacyNotice}
          </p>
        </div>
      </div>
    </div>
  );
};
