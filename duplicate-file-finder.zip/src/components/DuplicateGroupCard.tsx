/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DuplicateGroup, ScannedFile, Language } from '../types';
import { translations } from '../translations';
import { formatBytes } from './ScannerStats';
import { Trash2, ShieldCheck, FileText, Eye, CheckCircle2, Circle, AlertTriangle } from 'lucide-react';

interface DuplicateGroupCardProps {
  group: DuplicateGroup;
  language: Language;
  onFileClick: (file: ScannedFile) => void;
  onToggleDeletion: (fileId: string) => void;
  onSetPrimary: (fileId: string) => void;
}

export const DuplicateGroupCard: React.FC<DuplicateGroupCardProps> = ({
  group,
  language,
  onFileClick,
  onToggleDeletion,
  onSetPrimary,
}) => {
  const t = translations[language];

  // Pick the representative info
  const firstFile = group.files[0];
  const otherCount = group.files.length - 1;
  const hashAbbr = `${group.hash.substring(0, 8)}...${group.hash.substring(group.hash.length - 8)}`;

  // Total size wasted in this group
  const totalWastedBytes = group.files.reduce((acc, f) => {
    if (f.id !== group.primaryFileId && group.selectedForDeletion[f.id]) {
      return acc + f.size;
    }
    return acc;
  }, 0);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-lg overflow-hidden hover:border-slate-700 hover:shadow-xl transition-all flex flex-col" id={`group-card-${group.hash}`}>
      {/* Group Header */}
      <div className="bg-slate-950 border-b border-slate-800 px-5 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center space-x-2">
            <span className="text-[11px] font-mono font-bold bg-slate-800 text-indigo-300 border border-slate-700/50 px-2.5 py-0.5 rounded-md">
              HASH: {hashAbbr}
            </span>
            <span className="text-xs font-semibold text-slate-400">
              ({group.files.length} {language === 'en' ? 'copies' : 'nakala'})
            </span>
          </div>
          <p className="text-xs text-slate-300 font-semibold font-mono truncate mt-1">
            {firstFile.name}
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <span className="text-xs font-mono text-slate-400">
            {formatBytes(firstFile.size)} {language === 'en' ? 'each' : 'kila moja'}
          </span>
          {totalWastedBytes > 0 && (
            <span className="text-[10px] font-bold text-rose-400 bg-rose-950/30 border border-rose-900/30 px-2 py-0.5 rounded-md">
              {language === 'en' ? 'Saves' : 'Inaokoa'} {formatBytes(totalWastedBytes)}
            </span>
          )}
        </div>
      </div>

      {/* File List */}
      <div className="divide-y divide-slate-800/60" id={`group-list-${group.hash}`}>
        {group.files.map((file) => {
          const isPrimary = file.id === group.primaryFileId;
          const isSelectedForDeletion = group.selectedForDeletion[file.id];

          return (
            <div
              key={file.id}
              className={`p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 transition-all ${
                isPrimary
                  ? 'bg-emerald-950/10 hover:bg-emerald-950/20'
                  : isSelectedForDeletion
                  ? 'bg-rose-950/5 hover:bg-rose-950/10'
                  : 'hover:bg-slate-800/30'
              }`}
            >
              {/* Info Column */}
              <div className="min-w-0 flex items-start space-x-3">
                <button
                  type="button"
                  onClick={() => onSetPrimary(file.id)}
                  className={`mt-1 focus:outline-hidden transition-colors cursor-pointer ${
                    isPrimary ? 'text-emerald-400' : 'text-slate-600 hover:text-slate-400'
                  }`}
                  title={isPrimary ? 'Currently preserved master' : 'Set as preserved master'}
                >
                  {isPrimary ? (
                    <CheckCircle2 className="h-5 w-5 fill-emerald-950/50" />
                  ) : (
                    <Circle className="h-5 w-5" />
                  )}
                </button>

                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      onClick={() => onFileClick(file)}
                      className={`text-xs font-semibold cursor-pointer truncate hover:underline ${
                        isSelectedForDeletion ? 'text-slate-500 line-through' : 'text-slate-200'
                      }`}
                    >
                      {file.path}
                    </span>
                    
                    {/* Status badge */}
                    {isPrimary ? (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                        {t.keepTag}
                      </span>
                    ) : isSelectedForDeletion ? (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20 font-mono">
                        {t.deleteTag}
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-700/60 font-mono">
                        SKIP
                      </span>
                    )}
                  </div>

                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {language === 'en' ? 'Modified: ' : 'Ilibadilishwa: '}
                    {new Date(file.lastModified).toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end space-x-1.5">
                <button
                  onClick={() => onFileClick(file)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all flex items-center space-x-1 cursor-pointer"
                  title={t.viewDetails}
                >
                  <Eye className="h-4 w-4 text-indigo-400" />
                  <span className="text-[11px] font-medium hidden md:inline">{t.viewDetails}</span>
                </button>

                {!isPrimary && (
                  <button
                    onClick={() => onToggleDeletion(file.id)}
                    className={`p-1.5 rounded-lg transition-all flex items-center space-x-1 cursor-pointer ${
                      isSelectedForDeletion
                        ? 'text-rose-400 bg-rose-950/40 border border-rose-900/40 hover:bg-rose-900/40'
                        : 'text-slate-500 hover:bg-slate-800 hover:text-slate-300 border border-transparent'
                    }`}
                    title={t.deleteManual}
                  >
                    <Trash2 className="h-4 w-4" />
                    <span className="text-[11px] font-medium hidden md:inline">
                      {isSelectedForDeletion 
                        ? (language === 'en' ? 'Marked' : 'Imechaguliwa')
                        : (language === 'en' ? 'Mark' : 'Chagua')}
                    </span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
