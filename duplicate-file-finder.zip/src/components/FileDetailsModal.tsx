/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { ScannedFile, Language } from '../types';
import { translations } from '../translations';
import { formatBytes } from './ScannerStats';
import { X, Calendar, FileText, FileImage, FileAudio, FileVideo, HardDrive, Hash, Check } from 'lucide-react';

interface FileDetailsModalProps {
  fileData: ScannedFile;
  language: Language;
  onClose: () => void;
  isPrimary: boolean;
  onMakePrimary: () => void;
}

export const FileDetailsModal: React.FC<FileDetailsModalProps> = ({
  fileData,
  language,
  onClose,
  isPrimary,
  onMakePrimary,
}) => {
  const t = translations[language];
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  const [textContent, setTextContent] = useState<string | null>(null);

  useEffect(() => {
    // Generate object URL for media preview
    let url: string | null = null;
    if (fileData.type === 'image' || fileData.type === 'audio' || fileData.type === 'video') {
      url = URL.createObjectURL(fileData.file);
      setObjectUrl(url);
    }

    // Read text/code preview
    if (fileData.type === 'code' || fileData.type === 'document' || fileData.mimeType.startsWith('text/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        // Limit preview size to first 3000 chars
        setTextContent(text.slice(0, 3000) + (text.length > 3000 ? '\n... [truncated]' : ''));
      };
      reader.readAsText(fileData.file.slice(0, 5000));
    }

    return () => {
      if (url) {
        URL.revokeObjectURL(url);
      }
      setTextContent(null);
      setObjectUrl(null);
    };
  }, [fileData]);

  const renderPreview = () => {
    if (fileData.type === 'image' && objectUrl) {
      return (
        <div className="w-full flex justify-center bg-slate-950 border border-slate-800 rounded-xl p-4 max-h-72 overflow-hidden">
          <img
            src={objectUrl}
            alt={fileData.name}
            className="max-h-64 object-contain rounded-lg shadow-md"
            referrerPolicy="no-referrer"
          />
        </div>
      );
    }

    if (fileData.type === 'audio' && objectUrl) {
      return (
        <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center space-y-4 animate-pulse">
          <FileAudio className="h-14 w-14 text-indigo-400" />
          <audio controls src={objectUrl} className="w-full max-w-md" />
        </div>
      );
    }

    if (fileData.type === 'video' && objectUrl) {
      return (
        <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 max-h-72 overflow-hidden flex justify-center">
          <video controls src={objectUrl} className="max-h-64 rounded-lg" />
        </div>
      );
    }

    if (textContent !== null) {
      return (
        <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 max-h-72 overflow-y-auto">
          <pre className="text-left font-mono text-[11px] text-slate-300 leading-relaxed whitespace-pre-wrap">
            {textContent || '[Empty File]'}
          </pre>
        </div>
      );
    }

    // Generic Icon Fallback
    const Icon = fileData.type === 'image' ? FileImage 
                : fileData.type === 'audio' ? FileAudio 
                : fileData.type === 'video' ? FileVideo 
                : FileText;

    return (
      <div className="w-full bg-slate-950 border border-slate-800 rounded-xl py-12 flex flex-col items-center justify-center text-slate-500 space-y-3">
        <Icon className="h-16 w-16 text-slate-700" />
        <span className="text-xs font-semibold text-slate-400">
          {language === 'en' ? 'Preview not available for this format' : 'Hakiki haipatikani kwa faili la aina hii'}
        </span>
        <span className="text-[10px] bg-slate-900 text-slate-400 border border-slate-800 px-2.5 py-1 rounded-md font-mono">
          {fileData.mimeType || 'unknown/binary'}
        </span>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4 transition-all" id="file-details-overlay">
      <div className="bg-slate-900 rounded-3xl w-full max-w-2xl shadow-2xl border border-slate-800 flex flex-col overflow-hidden max-h-[90vh] animate-in fade-in zoom-in duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center space-x-2.5">
            <span className="p-1.5 bg-slate-900 rounded-lg text-indigo-400">
              <FileText className="h-4.5 w-4.5" />
            </span>
            <h3 className="font-bold text-white text-base truncate max-w-[350px]">
              {fileData.name}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
            id="modal-close-btn"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 bg-slate-900">
          {/* File Preview */}
          {renderPreview()}

          {/* Details Table */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Relative path */}
            <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-xl">
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider mb-0.5">
                {t.filePath}
              </span>
              <span className="font-mono text-slate-300 break-all select-all font-medium">
                {fileData.path}
              </span>
            </div>

            {/* Size */}
            <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-xl">
              <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider mb-0.5">
                {t.fileSize}
              </span>
              <span className="font-mono text-slate-300 font-semibold text-sm">
                {formatBytes(fileData.size)} <span className="text-[10px] font-normal text-slate-500">({fileData.size} {t.sizeBytes})</span>
              </span>
            </div>

            {/* Hash */}
            <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-xl md:col-span-2">
              <div className="flex items-center space-x-1.5 mb-1">
                <Hash className="h-3.5 w-3.5 text-indigo-400" />
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                  {t.fileHash}
                </span>
              </div>
              <span className="font-mono text-xs text-indigo-400 bg-indigo-950/50 border border-indigo-900/30 px-2 py-1 rounded-md block break-all font-semibold">
                {fileData.hash}
              </span>
            </div>

            {/* Last modified */}
            <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-xl md:col-span-2">
              <div className="flex items-center space-x-1.5 mb-1">
                <Calendar className="h-3.5 w-3.5 text-amber-500" />
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                  {t.fileModified}
                </span>
              </div>
              <span className="font-mono text-slate-300">
                {new Date(fileData.lastModified).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center">
            {isPrimary ? (
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Check className="h-3.5 w-3.5 mr-1" />
                {language === 'en' ? 'Preserved Master' : 'Faili Kuu la Kubakiza'}
              </span>
            ) : (
              <button
                type="button"
                onClick={() => {
                  onMakePrimary();
                  onClose();
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition-all shadow-lg shadow-emerald-600/10 flex items-center space-x-1 cursor-pointer"
                id="btn-make-master"
              >
                <Check className="h-3.5 w-3.5" />
                <span>{t.makePrimary}</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold transition-all cursor-pointer"
            id="modal-footer-close-btn"
          >
            {t.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
