/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ScannedFile {
  id: string;
  name: string;
  path: string; // Relative path in the selected folder
  size: number;
  type: string; // general category: 'image' | 'audio' | 'video' | 'document' | 'code' | 'other'
  mimeType: string;
  lastModified: number;
  hash: string; // SHA-256 hash
  file: File; // Reference to the original HTML5 File object for previewing
}

export interface DuplicateGroup {
  hash: string;
  files: ScannedFile[];
  primaryFileId: string; // The one file we choose to KEEP
  selectedForDeletion: Record<string, boolean>; // Map of fileId -> should be deleted
}

export interface ScanStats {
  totalFiles: number;
  totalSize: number;
  duplicateCount: number;
  duplicateSize: number;
  scanTimeMs: number;
  isScanning: boolean;
  currentProgress: number; // percentage 0-100
  currentFileName: string;
}

export type Language = 'sw' | 'en';

export type FileFilterType = 'all' | 'image' | 'audio' | 'video' | 'document' | 'code' | 'other';
