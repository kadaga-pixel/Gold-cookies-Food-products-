/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useTransition, useMemo } from 'react';
import { ScannedFile, DuplicateGroup, ScanStats, Language, FileFilterType } from './types';
import { translations } from './translations';
import { Header } from './components/Header';
import { FolderUpload } from './components/FolderUpload';
import { ScannerStats, formatBytes } from './components/ScannerStats';
import { DuplicateGroupCard } from './components/DuplicateGroupCard';
import { CleanActions } from './components/CleanActions';
import { FileDetailsModal } from './components/FileDetailsModal';
import { 
  Search, 
  Layers, 
  CheckCircle2, 
  Settings2, 
  AlertCircle, 
  FolderSync, 
  Sparkles, 
  ArrowUpDown, 
  SlidersHorizontal 
} from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const t = translations[language];

  // Application core states
  const [scannedFiles, setScannedFiles] = useState<ScannedFile[]>([]);
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>([]);
  const [stats, setStats] = useState<ScanStats>({
    totalFiles: 0,
    totalSize: 0,
    duplicateCount: 0,
    duplicateSize: 0,
    scanTimeMs: 0,
    isScanning: false,
    currentProgress: 0,
    currentFileName: '',
  });

  // UI Interactive States
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<FileFilterType>('all');
  const [selectionStrategy, setSelectionStrategy] = useState<'oldest' | 'newest' | 'shortest' | 'longest'>('oldest');
  const [selectedFileDetails, setSelectedFileDetails] = useState<ScannedFile | null>(null);
  const [successNotification, setSuccessNotification] = useState<string | null>(null);

  const [, startTransition] = useTransition();

  // Helper: Categorize files based on extensions
  const getFileType = (file: File): FileFilterType => {
    const mime = file.type || '';
    const name = file.name.toLowerCase();

    if (mime.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp|svg|bmp|ico)$/.test(name)) {
      return 'image';
    }
    if (mime.startsWith('audio/') || /\.(mp3|wav|ogg|m4a|flac|aac)$/.test(name)) {
      return 'audio';
    }
    if (mime.startsWith('video/') || /\.(mp4|mkv|avi|mov|wmv|webm|flv)$/.test(name)) {
      return 'video';
    }
    if (mime.startsWith('text/') || /\.(txt|pdf|doc|docx|xls|xlsx|ppt|pptx|odt|ods|pages)$/.test(name)) {
      return 'document';
    }
    if (/\.(js|jsx|ts|tsx|html|css|json|py|sh|cs|cpp|java|go|rs|md|yaml|yml|xml|ini|php|rb|sql)$/.test(name)) {
      return 'code';
    }
    return 'other';
  };

  // Optimized File Hashing using Web Crypto SHA-256 with large-file chunking guards
  const calculateFastFingerprint = async (file: File): Promise<string> => {
    const size = file.size;
    const megabyte = 1024 * 1024;

    try {
      // 1. For small files (<= 10MB), hash the entire content
      if (size <= 10 * megabyte) {
        const buffer = await file.arrayBuffer();
        const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
        return Array.from(new Uint8Array(hashBuffer))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('');
      }

      // 2. For larger files, create a composite slice hash (First 3MB + Last 2MB + Middle 1MB + size)
      // This is extremely collision-resistant and runs in <50ms even for a 5GB file
      const slice1 = file.slice(0, 3 * megabyte);
      const slice2 = file.slice(Math.floor(size / 2) - 512 * 1024, Math.floor(size / 2) + 512 * 1024);
      const slice3 = file.slice(size - 2 * megabyte, size);

      const [buf1, buf2, buf3] = await Promise.all([
        slice1.arrayBuffer(),
        slice2.arrayBuffer(),
        slice3.arrayBuffer(),
      ]);

      const combined = new Uint8Array(buf1.byteLength + buf2.byteLength + buf3.byteLength + 8);
      combined.set(new Uint8Array(buf1), 0);
      combined.set(new Uint8Array(buf2), buf1.byteLength);
      combined.set(new Uint8Array(buf3), buf1.byteLength + buf2.byteLength);

      // Pack total file size at the end to guarantee size check
      const view = new DataView(combined.buffer);
      view.setBigUint64(combined.byteLength - 8, BigInt(size));

      const hashBuffer = await crypto.subtle.digest('SHA-256', combined.buffer);
      return Array.from(new Uint8Array(hashBuffer))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    } catch (err) {
      // Return a basic pseudorandom hash as fallback
      return `err-${file.name}-${size}-${file.lastModified}`;
    }
  };

  // Scan processor loop
  const handleFilesSelected = async (files: File[]) => {
    if (files.length === 0) return;

    setStats((prev) => ({
      ...prev,
      isScanning: true,
      currentProgress: 0,
      totalFiles: files.length,
      currentFileName: '',
    }));

    setScannedFiles([]);
    setDuplicateGroups([]);

    const startTime = performance.now();
    const list: ScannedFile[] = [];
    const hashMap: Record<string, ScannedFile[]> = {};

    // Process sequentially in micro-batches to prevent thread freezing
    const batchSize = 10;
    for (let i = 0; i < files.length; i += batchSize) {
      const chunk = files.slice(i, i + batchSize);
      
      await Promise.all(
        chunk.map(async (file, chunkIdx) => {
          const fileIndex = i + chunkIdx;
          const hashValue = await calculateFastFingerprint(file);
          
          // Determine path: prefer webkitRelativePath, fallback to name
          const relativePath = file.webkitRelativePath || file.name;

          const scFile: ScannedFile = {
            id: `${hashValue}-${fileIndex}-${file.lastModified}`,
            name: file.name,
            path: relativePath,
            size: file.size,
            type: getFileType(file),
            mimeType: file.type,
            lastModified: file.lastModified,
            hash: hashValue,
            file: file,
          };

          list.push(scFile);

          if (!hashMap[hashValue]) {
            hashMap[hashValue] = [];
          }
          hashMap[hashValue].push(scFile);
        })
      );

      // Update progress periodically
      const progressPercent = Math.min(100, Math.round(((i + chunk.length) / files.length) * 100));
      const lastFile = chunk[chunk.length - 1];

      setStats((prev) => ({
        ...prev,
        currentProgress: progressPercent,
        currentFileName: lastFile ? lastFile.name : '',
        totalFiles: list.length,
      }));
    }

    // Identify and group duplicates
    const finalGroups: DuplicateGroup[] = [];
    let duplicateFileCount = 0;
    let duplicateTotalBytes = 0;
    let folderTotalBytes = 0;

    list.forEach((f) => {
      folderTotalBytes += f.size;
    });

    Object.entries(hashMap).forEach(([hash, groupedFiles]) => {
      if (groupedFiles.length > 1) {
        // Default Strategy: Keep oldest
        const sorted = [...groupedFiles].sort((a, b) => a.lastModified - b.lastModified);
        const primary = sorted[0]; // Oldest

        const deletionMap: Record<string, boolean> = {};
        sorted.forEach((f) => {
          if (f.id !== primary.id) {
            deletionMap[f.id] = true;
            duplicateFileCount++;
            duplicateTotalBytes += f.size;
          } else {
            deletionMap[f.id] = false;
          }
        });

        finalGroups.push({
          hash,
          files: sorted,
          primaryFileId: primary.id,
          selectedForDeletion: deletionMap,
        });
      }
    });

    const endTime = performance.now();

    setScannedFiles(list);
    setDuplicateGroups(finalGroups);
    setStats({
      totalFiles: list.length,
      totalSize: folderTotalBytes,
      duplicateCount: duplicateFileCount,
      duplicateSize: duplicateTotalBytes,
      scanTimeMs: Math.round(endTime - startTime),
      isScanning: false,
      currentProgress: 100,
      currentFileName: '',
    });
    setSelectionStrategy('oldest');
  };

  // Interactive selection strategy updating (oldest, newest, shortest, longest paths)
  const applySelectionStrategy = (strategy: 'oldest' | 'newest' | 'shortest' | 'longest') => {
    setSelectionStrategy(strategy);
    
    startTransition(() => {
      setDuplicateGroups((prevGroups) => {
        let updatedDupCount = 0;
        let updatedDupSize = 0;

        const next = prevGroups.map((group) => {
          let primary: ScannedFile;

          if (strategy === 'oldest') {
            primary = [...group.files].reduce((oldest, f) => 
              f.lastModified < oldest.lastModified ? f : oldest
            , group.files[0]);
          } else if (strategy === 'newest') {
            primary = [...group.files].reduce((newest, f) => 
              f.lastModified > newest.lastModified ? f : newest
            , group.files[0]);
          } else if (strategy === 'shortest') {
            primary = [...group.files].reduce((shortest, f) => 
              f.path.length < shortest.path.length ? f : shortest
            , group.files[0]);
          } else { // longest path
            primary = [...group.files].reduce((longest, f) => 
              f.path.length > longest.path.length ? f : longest
            , group.files[0]);
          }

          const deletionMap: Record<string, boolean> = {};
          group.files.forEach((f) => {
            if (f.id !== primary.id) {
              deletionMap[f.id] = true;
              updatedDupCount++;
              updatedDupSize += f.size;
            } else {
              deletionMap[f.id] = false;
            }
          });

          return {
            ...group,
            primaryFileId: primary.id,
            selectedForDeletion: deletionMap,
          };
        });

        // Update stats
        setStats((prev) => ({
          ...prev,
          duplicateCount: updatedDupCount,
          duplicateSize: updatedDupSize,
        }));

        return next;
      });
    });
  };

  // Toggle individual duplicate item deletion flag manually
  const handleToggleDeletion = (hash: string, fileId: string) => {
    setDuplicateGroups((prev) => {
      let diffSize = 0;
      let diffCount = 0;

      const next = prev.map((group) => {
        if (group.hash === hash) {
          const currentVal = group.selectedForDeletion[fileId];
          const newVal = !currentVal;
          const file = group.files.find((f) => f.id === fileId);
          
          if (file) {
            diffSize = newVal ? file.size : -file.size;
            diffCount = newVal ? 1 : -1;
          }

          return {
            ...group,
            selectedForDeletion: {
              ...group.selectedForDeletion,
              [fileId]: newVal,
            },
          };
        }
        return group;
      });

      setStats((prevStats) => ({
        ...prevStats,
        duplicateCount: prevStats.duplicateCount + diffCount,
        duplicateSize: prevStats.duplicateSize + diffSize,
      }));

      return next;
    });
  };

  // Promote a specific copy as the primary keeper
  const handleSetPrimary = (hash: string, fileId: string) => {
    setDuplicateGroups((prev) => {
      let diffSize = 0;
      let diffCount = 0;

      const next = prev.map((group) => {
        if (group.hash === hash) {
          const oldPrimary = group.files.find((f) => f.id === group.primaryFileId);
          const newPrimary = group.files.find((f) => f.id === fileId);

          const deletionMap: Record<string, boolean> = {};
          
          group.files.forEach((f) => {
            if (f.id === fileId) {
              // Master file is kept
              deletionMap[f.id] = false;
              if (group.selectedForDeletion[f.id]) {
                diffSize -= f.size;
                diffCount--;
              }
            } else {
              // Others default to selected for deletion
              deletionMap[f.id] = true;
              if (!group.selectedForDeletion[f.id]) {
                diffSize += f.size;
                diffCount++;
              }
            }
          });

          return {
            ...group,
            primaryFileId: fileId,
            selectedForDeletion: deletionMap,
          };
        }
        return group;
      });

      setStats((prevStats) => ({
        ...prevStats,
        duplicateCount: prevStats.duplicateCount + diffCount,
        duplicateSize: prevStats.duplicateSize + diffSize,
      }));

      return next;
    });
  };

  // Perform Simulated Cleanup (remove them from the UI list)
  const handleSimulateClean = () => {
    const cleanedSize = stats.duplicateSize;
    
    // Purge marked duplicates from groups
    const nextGroups = duplicateGroups
      .map((group) => {
        const remainingFiles = group.files.filter(
          (f) => f.id === group.primaryFileId || !group.selectedForDeletion[f.id]
        );
        return {
          ...group,
          files: remainingFiles,
        };
      })
      .filter((group) => group.files.length > 1);

    setDuplicateGroups(nextGroups);
    setStats((prev) => ({
      ...prev,
      duplicateCount: 0,
      duplicateSize: 0,
      totalSize: prev.totalSize - cleanedSize,
    }));

    const formattedReclaimed = formatBytes(cleanedSize);
    setSuccessNotification(
      t.cleanSuccessMsg.replace('{size}', formattedReclaimed)
    );

    setTimeout(() => {
      setSuccessNotification(null);
    }, 5000);
  };

  // Filters + Search Query Matcher
  const filteredGroups = useMemo(() => {
    return duplicateGroups.filter((group) => {
      // File type categorization
      const matchesType = filterType === 'all' || group.files.some((f) => f.type === filterType);
      
      // Filename searching
      const matchesSearch = searchQuery.trim() === '' || group.files.some((f) => 
        f.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        f.path.toLowerCase().includes(searchQuery.toLowerCase())
      );

      return matchesType && matchesSearch;
    });
  }, [duplicateGroups, filterType, searchQuery]);

  return (
    <div className="min-h-screen bg-slate-950 font-sans flex flex-col text-slate-200" id="main-app">
      <Header language={language} setLanguage={setLanguage} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Step 1: Folder Selection / Uploader */}
        <section aria-label="Folder Scanning Zone" id="section-scanner">
          <FolderUpload
            language={language}
            isScanning={stats.isScanning}
            onFilesSelected={handleFilesSelected}
          />
        </section>

        {/* Scan Results Area */}
        {stats.totalFiles > 0 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-3 duration-200">
            {/* Stats Dashboard */}
            <section aria-label="Scanned Folder Statistics" id="section-stats">
              <ScannerStats stats={stats} language={language} />
            </section>

            {/* Success simulated banner */}
            {successNotification && (
              <div className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 p-4 rounded-xl flex items-center justify-between shadow-lg font-semibold text-xs md:text-sm animate-bounce" id="success-banner">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />
                  <span>{successNotification}</span>
                </div>
                <button 
                  onClick={() => setSuccessNotification(null)}
                  className="hover:bg-emerald-500/10 p-1 rounded-md transition-all text-emerald-400 cursor-pointer"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Automation scripts / Remediations */}
            {duplicateGroups.length > 0 && (
              <section aria-label="Action Deck" id="section-actions">
                <CleanActions
                  groups={duplicateGroups}
                  language={language}
                  onSimulateClean={handleSimulateClean}
                />
              </section>
            )}

            {/* Step 2: Custom Selection Strategies, Filter, and search */}
            <section aria-label="Duplicate Filter Controls" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl" id="control-panel">
              <div className="flex flex-col xl:flex-row gap-5 justify-between">
                
                {/* Search and Categories row */}
                <div className="flex-1 space-y-4">
                  <div className="flex flex-col sm:flex-row gap-3">
                    {/* Search Field */}
                    <div className="relative flex-1">
                      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                      <input
                        type="text"
                        placeholder={t.searchPlaceholder}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs focus:bg-slate-950 focus:outline-hidden focus:border-indigo-500 transition-all text-slate-200 placeholder-slate-500"
                        id="search-input"
                      />
                    </div>

                    {/* Auto Selector Widget */}
                    {duplicateGroups.length > 0 && (
                      <div className="flex items-center space-x-2 shrink-0 bg-slate-950 border border-slate-800 p-1 rounded-xl">
                        <ArrowUpDown className="h-3.5 w-3.5 text-slate-500 ml-1.5" />
                        <select
                          value={selectionStrategy}
                          onChange={(e) => applySelectionStrategy(e.target.value as any)}
                          className="bg-transparent text-xs font-semibold text-slate-300 py-1.5 pr-8 pl-1 focus:outline-hidden cursor-pointer"
                          id="select-strategy"
                          title={t.autoSelectTitle}
                        >
                          <option value="oldest" className="bg-slate-950">{t.autoSelectKeepOldest}</option>
                          <option value="newest" className="bg-slate-950">{t.autoSelectKeepNewest}</option>
                          <option value="shortest" className="bg-slate-950">{t.autoSelectKeepShortPath}</option>
                          <option value="longest" className="bg-slate-950">{t.autoSelectKeepLongPath}</option>
                        </select>
                      </div>
                    )}
                  </div>

                  {/* Horizontal Scroll Filter Chips */}
                  <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 no-scrollbar" id="type-filter-chips">
                    <SlidersHorizontal className="h-3.5 w-3.5 text-slate-500 shrink-0 mr-1 hidden sm:block" />
                    {[
                      { key: 'all', label: t.filterAll },
                      { key: 'image', label: t.filterImages },
                      { key: 'audio', label: t.filterAudio },
                      { key: 'video', label: t.filterVideo },
                      { key: 'document', label: t.filterDocs },
                      { key: 'code', label: t.filterCode },
                      { key: 'other', label: t.filterOthers },
                    ].map((chip) => (
                      <button
                        key={chip.key}
                        onClick={() => setFilterType(chip.key as FileFilterType)}
                        className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all shrink-0 border cursor-pointer ${
                          filterType === chip.key
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-600/15'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-850 hover:text-white'
                        }`}
                        id={`filter-chip-${chip.key}`}
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Info Text about strategy */}
                {duplicateGroups.length > 0 && (
                  <div className="xl:max-w-xs bg-slate-950/65 rounded-xl p-3.5 border border-slate-850 flex items-start space-x-2.5 text-[11px] text-slate-400">
                    <Settings2 className="h-4.5 w-4.5 text-slate-500 mt-0.5 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-300 block mb-0.5">{t.autoSelectTitle}</span>
                      <p className="leading-relaxed">{t.autoSelectDesc}</p>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* List of Duplicate Groups */}
            <section aria-label="Duplicate List Section" className="space-y-4" id="section-duplicate-groups">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Layers className="h-4 w-4 text-indigo-400" />
                  {t.duplicateGroups} ({filteredGroups.length})
                </h3>
              </div>

              {filteredGroups.length > 0 ? (
                <div className="grid grid-cols-1 gap-4" id="groups-grid">
                  {filteredGroups.map((group) => (
                    <DuplicateGroupCard
                      key={group.hash}
                      group={group}
                      language={language}
                      onFileClick={setSelectedFileDetails}
                      onToggleDeletion={(fileId) => handleToggleDeletion(group.hash, fileId)}
                      onSetPrimary={(fileId) => handleSetPrimary(group.hash, fileId)}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl py-16 px-4 text-center text-slate-400 shadow-md" id="no-duplicates-alert">
                  <CheckCircle2 className="h-12 w-12 text-emerald-400 mx-auto mb-3" />
                  <p className="text-sm font-bold text-white mb-1">
                    {t.noDuplicatesFound}
                  </p>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                    {language === 'en' 
                      ? 'Try shifting filter chips or search queries above to see matching results.' 
                      : 'Jaribu kubadilisha vichungi au maneno ya utafutaji hapo juu kuona matokeo yanayolingana.'}
                  </p>
                </div>
              )}
            </section>
          </div>
        )}

        {/* Empty State when no folder scanned yet */}
        {stats.totalFiles === 0 && !stats.isScanning && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl py-16 px-4 text-center text-slate-400 shadow-lg" id="empty-state-card">
            <Sparkles className="h-12 w-12 text-slate-600 mx-auto mb-3 animate-pulse" />
            <p className="text-sm font-bold text-white mb-1">
              {t.selectFolderFirst}
            </p>
            <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
              {language === 'en' 
                ? 'Your scanning speed is fully optimized for huge libraries.' 
                : 'Kasi yako ya kusoma imeimarishwa vizuri kwa ajili ya maktaba kubwa.'}
            </p>
          </div>
        )}

        {/* Floating Instruction Widget */}
        <section aria-label="Swahili Code Reference Panel" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md" id="original-code-preview">
          <div className="flex items-start space-x-3.5">
            <div className="h-9 w-9 bg-slate-950 text-indigo-400 rounded-xl border border-slate-800 shadow-md flex items-center justify-center font-black text-sm select-none">
              F
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-bold text-white">
                {language === 'en' ? 'Original Swahili Algorithm Reference' : 'Rejeleo la Algorithm yako ya Kiswahili'}
              </h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {language === 'en'
                  ? 'Your python script uses md5 hash buffers and os.walk recursive lookup. The browser counterpart runs on parallel high-throughput Web Crypto SHA-256 engines for safety.'
                  : 'Script yako ya python inatumia bafa za md5 hash na ukaguzi wa os.walk recursive. Mfumo huu wa kivinjari unaendesha amri za kisasa za Web Crypto SHA-256 kwa kasi zaidi.'}
              </p>
              
              {/* Collapsible/Elegant Preview of code */}
              <div className="mt-4 bg-slate-950 rounded-xl p-4 border border-slate-850 overflow-x-auto shadow-inner">
                <pre className="text-left font-mono text-[10px] md:text-xs text-slate-400 leading-relaxed whitespace-pre">
{`def hesabu_hash(njia_ya_file):
    hasher = hashlib.md5()
    with open(njia_ya_file, 'rb') as f:
        pande = f.read(1024*1024) # Soma megabyte moja moja
        while len(pande) > 0:
            hasher.update(pande)
            pande = f.read(1024*1024)
    return hasher.hexdigest()`}
                </pre>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* File Details / Preview Modal Overlay */}
      {selectedFileDetails && (
        <FileDetailsModal
          fileData={selectedFileDetails}
          language={language}
          onClose={() => setSelectedFileDetails(null)}
          isPrimary={
            duplicateGroups.find((g) => g.hash === selectedFileDetails.hash)?.primaryFileId ===
            selectedFileDetails.id
          }
          onMakePrimary={() => handleSetPrimary(selectedFileDetails.hash, selectedFileDetails.id)}
        />
      )}

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900/60 py-6 mt-12 text-center text-xs text-slate-500" id="app-footer">
        <p className="font-mono">
          © 2026 {t.appTitle} | {t.createdWithLove}
        </p>
      </footer>
    </div>
  );
}
